<template>
  <ToastProvider>
    <App />
  </ToastProvider>
</template>

<script setup lang="ts">
import ToastProvider from './components/ToastProvider.vue';
import App from './App.vue';
</script>
